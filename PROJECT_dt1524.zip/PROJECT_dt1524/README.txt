All Data files used are available in the unedited version of this folder (.csv, excel files are here as reference but are not used.)

Files:
- THESIS_DATA_TEST_BLACKSITE: all models are ran here
- thesis_NOTEBK: preliminary data analysis is in here, same content as Milestone 1.
- wrap_up: visualizations are generated here, using results from Blacksite file.
- datamuncher and datamuncher2 - used to edit .csv files to tailor for model application

________________________________________________________________________________________

contacts:
dt1524@ic.ac.uk
dt2190@nyu.edu